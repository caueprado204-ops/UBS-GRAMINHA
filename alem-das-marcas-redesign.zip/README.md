# Além das Marcas — Violência contra a Mulher

Projeto educativo, informativo e responsivo desenvolvido com React + Vite + Tailwind CSS + Lucide React.

## Rodar localmente

Requisitos: Node.js 20+ recomendado.

```bash
npm install
npm run dev
```

Depois, abra o endereço mostrado pelo Vite.

Para produção:

```bash
npm run build
npm run preview
```

## Estrutura

- `src/main.jsx` — ponto de entrada.
- `src/App.jsx` — composição das seções e estado da aplicação.
- `src/data.js` — todo o conteúdo textual (tipos de violência, sinais, mitos, frases, links de ajuda, fontes).
- `src/components/` — Navbar, Hero, EditorialIntro, ViolenceTypes, ViolenceCard, SignsSection, SignsItem, MythsSection, MythCard, QuoteSection, HelpSection, Footer, BackgroundGlow, GlassShape.
- `src/styles.css` — identidade visual (editorial/glassmorphism roxo), grid de linhas verticais, gradientes de fundo por seção e responsividade.
- `index.html` — metadados básicos.

## Identidade visual (redesign)

Paleta dominada por roxos (#7C3AED, #8B5CF6, #A855F7, #C084FC) sobre fundo quase branco/lilás, com roxo profundo (#35134F/#24102F) na seção "Você reconhece esses sinais?" e no rodapé. Tipografia: Playfair Display (títulos) + DM Sans (texto). Uso moderado de glassmorphism, gradientes radiais suaves por seção, grid editorial de linhas verticais finas e tipografia oversized no Hero, na seção de sinais e no rodapé. Cor vinho original mantida apenas como detalhe pontual no selo "MITO" da seção de mitos e verdades.

## Conteúdo e fontes

O conteúdo jurídico principal foi alinhado à Lei Maria da Penha (Lei nº 11.340/2006), incluindo a alteração de 2026 que passou a reconhecer a violência vicária no art. 7º, VI.

Fontes oficiais:
- https://www.planalto.gov.br/ccivil_03/_ato2004-2006/2006/lei/l11340.htm
- https://www.gov.br/mj/pt-br/assuntos/sua-seguranca/seguranca-publica/susp-mulheres/violencia-domestica-e-familiar
- https://www.gov.br/pt-br/servicos/denunciar-e-buscar-ajuda-a-vitimas-de-violencia-contra-mulheres

O site evita estatísticas não necessárias e não apresenta números de contato sem fonte oficial.
