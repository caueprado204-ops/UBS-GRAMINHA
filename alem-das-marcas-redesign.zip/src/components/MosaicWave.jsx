import React from "react";

/**
 * Grade de blocos translúcidos organizados em "onda" — elemento
 * assinatura inspirado na referência visual (mosaico de blocos
 * de vidro formando um perfil irregular). Puramente decorativo.
 *
 * tone: "light" (sobre fundo claro) | "deep" (sobre fundo roxo profundo)
 */
const COLS = 9;
const ROWS = 7;
// altura preenchida (em blocos, a partir da base) de cada coluna —
// define o perfil irregular, "orgânico" da onda.
const WAVE = [7, 5, 6, 4, 3, 5, 2, 4, 3];

export default function MosaicWave({ tone = "light", className = "" }) {
  const cells = [];
  for (let row = 0; row < ROWS; row++) {
    for (let col = 0; col < COLS; col++) {
      const filled = WAVE[col % WAVE.length];
      const fromBottom = ROWS - row;
      const active = fromBottom <= filled;
      const t = active ? fromBottom / filled : 0;
      const variance = ((row + col) % 3) * 0.05;
      const opacity = active ? Math.min(0.9, 0.22 + t * 0.55 + variance) : 0;
      cells.push({ key: `${row}-${col}`, opacity });
    }
  }

  return (
    <div
      className={`mosaic-wave mosaic-${tone} ${className}`}
      style={{ gridTemplateColumns: `repeat(${COLS}, 1fr)` }}
      aria-hidden="true"
    >
      {cells.map((c) => (
        <span key={c.key} className="mosaic-tile" style={{ opacity: c.opacity }} />
      ))}
    </div>
  );
}
