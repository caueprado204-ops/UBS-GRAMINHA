import React from "react";
import { Menu, X, Sparkles } from "lucide-react";

export default function Navbar({ menuOpen, setMenuOpen, scrollTo }) {
  return (
    <header className="nav-wrap">
      <nav className="nav container" aria-label="Navegação principal">
        <button className="brand" onClick={() => scrollTo("inicio")} aria-label="Voltar ao início">
          <span className="brand-mark"><Sparkles size={16} /></span>
          <span>Além das Marcas</span>
        </button>

        <button
          className="menu-button"
          aria-expanded={menuOpen}
          aria-controls="main-menu"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          {menuOpen ? <X /> : <Menu />}
          <span className="sr-only">Abrir menu</span>
        </button>

        <div id="main-menu" className={`nav-links ${menuOpen ? "open" : ""}`}>
          <button onClick={() => scrollTo("sobre")}>Sobre</button>
          <button onClick={() => scrollTo("tipos")}>Tipos</button>
          <button onClick={() => scrollTo("sinais")}>Sinais</button>
          <button onClick={() => scrollTo("mitos")}>Mitos &amp; verdades</button>
          <button className="nav-help" onClick={() => scrollTo("ajuda")}>Buscar ajuda</button>
        </div>
      </nav>
    </header>
  );
}
