import React from "react";
import { HeartHandshake } from "lucide-react";
import { signs } from "../data.js";
import SignsItem from "./SignsItem.jsx";
import BackgroundGlow from "./BackgroundGlow.jsx";

export default function SignsSection({ checkedSigns, toggleSign }) {
  return (
    <section id="sinais" className="section signs-section">
      <BackgroundGlow variant="deep" />
      <div className="grid-lines grid-lines-light" aria-hidden="true" />
      <div className="container signs-container">
        <div className="signs-head">
          <div className="section-kicker light">03 — OLHE COM ATENÇÃO</div>
          <h2 className="signs-title">Você<br />reconhece<br />esses sinais?</h2>
          <p>Leia cada situação com calma. Marcar uma ou mais não é um diagnóstico psicológico ou jurídico. É apenas um convite à reflexão.</p>
        </div>

        <div className="signs-panel">
          <div className="signs-list">
            {signs.map((sign, index) => (
              <SignsItem
                key={sign}
                sign={sign}
                index={index}
                selected={checkedSigns.includes(index)}
                onToggle={() => toggleSign(index)}
              />
            ))}
          </div>

          <div className={`recognition-message ${checkedSigns.length ? "visible" : ""}`}>
            <HeartHandshake size={20} />
            <div>
              <strong>Se você se identificou com alguma dessas situações, você não está sozinha.</strong>
              <p>Buscar informação, conversar com alguém de confiança e conhecer os serviços de apoio pode ser um passo importante.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
