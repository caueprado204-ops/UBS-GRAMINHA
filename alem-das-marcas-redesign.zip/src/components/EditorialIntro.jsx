import React from "react";

export default function EditorialIntro() {
  return (
    <section id="sobre" className="section intro-section">
      <span className="ghost-number" aria-hidden="true">01</span>
      <div className="container intro-grid">
        <div className="section-kicker">01 — ENTENDER É UM COMEÇO</div>
        <div>
          <h2>Nem toda violência<br />é visível.</h2>
          <p>
            A violência contra a mulher pode acontecer de diferentes formas e algumas delas
            são difíceis de perceber. Controle, humilhação, ameaças, coerção sexual e destruição
            de bens também podem fazer parte de situações abusivas.
          </p>
          <div className="statement">
            <span className="statement-line" />
            <strong>Toda mulher merece viver com liberdade, segurança, respeito e dignidade.</strong>
          </div>
        </div>
      </div>
    </section>
  );
}
