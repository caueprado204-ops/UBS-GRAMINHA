import React from "react";

export default function MythCard({ text, answer, explanation, index, open, onToggle }) {
  return (
    <button className={`myth-card ${open ? "open" : ""}`} onClick={onToggle} aria-expanded={open}>
      <span className="myth-ghost">0{index + 1}</span>
      <span className="myth-label">AFIRMAÇÃO 0{index + 1}</span>
      <p>{text}</p>
      {!open && <span className="myth-reveal">REVELAR →</span>}
      {open && (
        <>
          <span className={`answer-pill ${answer.toLowerCase()}`}>{answer}</span>
          <span className="answer-explain">{explanation}</span>
        </>
      )}
    </button>
  );
}
