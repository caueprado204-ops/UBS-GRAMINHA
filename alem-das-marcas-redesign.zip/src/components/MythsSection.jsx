import React from "react";
import { myths } from "../data.js";
import MythCard from "./MythCard.jsx";

export default function MythsSection({ openMyth, setOpenMyth }) {
  return (
    <section id="mitos" className="section myths-section">
      <div className="container">
        <div className="section-heading">
          <div>
            <div className="section-kicker">04 — DESFAÇA IDEIAS</div>
            <h2>Mitos &amp; verdades</h2>
          </div>
          <p>Algumas ideias podem normalizar comportamentos abusivos. Informação ajuda a enxergá-los de outra maneira.</p>
        </div>

        <div className="myths-grid">
          {myths.map(([text, answer, explanation], index) => {
            const open = openMyth === index;
            return (
              <MythCard
                key={text}
                text={text}
                answer={answer}
                explanation={explanation}
                index={index}
                open={open}
                onToggle={() => setOpenMyth(open ? null : index)}
              />
            );
          })}
        </div>
      </div>
    </section>
  );
}
