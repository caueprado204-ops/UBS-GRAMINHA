import React from "react";
import { ArrowRight, LockKeyhole, Sparkles } from "lucide-react";
import BackgroundGlow from "./BackgroundGlow.jsx";
import GlassShape from "./GlassShape.jsx";
import MosaicWave from "./MosaicWave.jsx";

export default function Hero({ scrollTo }) {
  return (
    <section id="inicio" className="hero section">
      <BackgroundGlow variant="hero" />
      <div className="grid-lines" aria-hidden="true" />

      <div className="container hero-grid">
        <div className="hero-copy reveal">
          <div className="eyebrow-stack">
            <span className="eyebrow-line">ALÉM DAS MARCAS</span>
            <span className="eyebrow-line eyebrow-sub">PROJETO DE CONSCIENTIZAÇÃO</span>
          </div>

          <h1 className="hero-title">
            Violência<Sparkles className="hero-sparkle" size={26} aria-hidden="true" /> <br className="hero-break" />
            não é apenas <br className="hero-break" />
            aquilo que deixa <br className="hero-break" />
            <em>marcas</em> no corpo.
          </h1>

          <p className="hero-lead">
            Conhecer os diferentes tipos de violência é um passo importante para reconhecer
            situações abusivas, buscar ajuda e proteger a si mesma e a outras mulheres.
          </p>

          <div className="hero-actions">
            <button className="primary-button" onClick={() => scrollTo("tipos")}>
              CONHECER OS TIPOS <ArrowRight size={15} />
            </button>
            <button className="text-button" onClick={() => scrollTo("sinais")}>
              RECONHECER OS SINAIS
            </button>
          </div>

          <div className="hero-note">
            <LockKeyhole size={15} />
            Informação, acolhimento e respeito — sem julgamentos.
          </div>
        </div>

        <div className="hero-art" aria-hidden="true">
          <MosaicWave tone="light" className="hero-mosaic" />
          <GlassShape className="shape shape-1" />
          <GlassShape className="shape shape-2" />
          <GlassShape className="shape shape-3" />
          <GlassShape className="shape shape-4" />
          <GlassShape className="shape shape-5" />

          <div className="micro-tag tag-1">
            <span className="micro-num">01</span>
            <span>RECONHECER</span>
          </div>
          <div className="micro-tag tag-2">
            <span className="micro-num">02</span>
            <span>INFORMAR</span>
          </div>
          <div className="micro-tag tag-3">
            <span className="micro-num">03</span>
            <span>PROTEGER</span>
          </div>

          <div className="micro-quote">
            INFORMAÇÃO<br />TAMBÉM É<br />UMA FORMA<br />DE PROTEÇÃO.
          </div>
        </div>
      </div>
    </section>
  );
}
