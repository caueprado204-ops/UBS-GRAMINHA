import React from "react";

/**
 * Bloco/retângulo translúcido usado nas composições abstratas
 * (Hero, Ajuda). Puramente decorativo.
 */
export default function GlassShape({ className = "", style = {} }) {
  return <div className={`glass-shape ${className}`} style={style} aria-hidden="true" />;
}
