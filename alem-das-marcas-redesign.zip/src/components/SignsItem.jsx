import React from "react";
import { Check } from "lucide-react";

export default function SignsItem({ sign, index, selected, onToggle }) {
  return (
    <button
      className={`sign-item ${selected ? "selected" : ""}`}
      onClick={onToggle}
      aria-pressed={selected}
    >
      <span className="sign-number">0{index + 1}</span>
      <span className="sign-text">{sign}</span>
      <span className="sign-check">{selected ? <Check size={13} /> : null}</span>
    </button>
  );
}
