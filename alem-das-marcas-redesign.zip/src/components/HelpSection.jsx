import React from "react";
import { ShieldCheck, Phone, Landmark, ExternalLink } from "lucide-react";
import { helpLinks } from "../data.js";
import BackgroundGlow from "./BackgroundGlow.jsx";
import GlassShape from "./GlassShape.jsx";

const iconFor = (i) => (i === 0 ? Phone : Landmark);

export default function HelpSection() {
  return (
    <section id="ajuda" className="section help-section">
      <BackgroundGlow variant="help" />
      <GlassShape className="shape help-shape-1" />
      <GlassShape className="shape help-shape-2" />
      <div className="container help-grid">
        <div className="reveal">
          <div className="section-kicker">05 — CAMINHOS DE APOIO</div>
          <h2>Você<br />não está<br />sozinha.</h2>
          <p>
            Uma pessoa que esteja passando por uma situação de violência pode procurar pessoas
            de confiança e serviços oficiais de apoio e proteção. Escolha um caminho que seja
            seguro para você.
          </p>
          <div className="safety-box">
            <ShieldCheck size={19} />
            <strong>Se você estiver em perigo imediato, procure um serviço de emergência ou um local seguro.</strong>
          </div>
        </div>

        <div className="help-cards">
          {helpLinks.map((link, i) => {
            const Icon = iconFor(i);
            return (
              <a className="help-card" href={link.href} target="_blank" rel="noreferrer" key={link.href}>
                <div className="help-icon"><Icon size={20} /></div>
                <div>
                  <span className="help-overline">{link.overline}</span>
                  <h3>{link.title}</h3>
                  <p>{link.text}</p>
                </div>
                <ExternalLink size={16} className="help-external" />
              </a>
            );
          })}
        </div>
      </div>
    </section>
  );
}
