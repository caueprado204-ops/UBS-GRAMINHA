import React from "react";
import { quotes } from "../data.js";

const styles = ["solid", "outline", "gradient", "italic", "solid"];

export default function QuoteSection() {
  return (
    <section className="quotes-section" aria-label="Frases de conscientização">
      <div className="grid-lines" aria-hidden="true" />
      <div className="container quotes-grid">
        {quotes.map((quote, i) => (
          <div className={`quote quote-${styles[i % styles.length]}`} key={quote}>
            <span className="quote-num">0{i + 1}</span>
            <strong>{quote}</strong>
          </div>
        ))}
      </div>
    </section>
  );
}
