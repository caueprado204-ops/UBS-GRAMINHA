import React from "react";
import { Sparkles } from "lucide-react";
import { sources } from "../data.js";
import MosaicWave from "./MosaicWave.jsx";

export default function Footer({ scrollTo }) {
  return (
    <footer className="footer">
      <div className="grid-lines grid-lines-light" aria-hidden="true" />
      <MosaicWave tone="deep" className="footer-mosaic" />
      <div className="container footer-top">
        <h2 className="footer-statement">
          Informação<br />também é uma<br />forma de proteção.
        </h2>
      </div>
      <div className="container footer-grid">
        <div>
          <div className="brand footer-brand"><span className="brand-mark"><Sparkles size={15} /></span><span>Além das Marcas</span></div>
          <p>Projeto educativo</p>
        </div>
        <div className="footer-links">
          <button onClick={() => scrollTo("sobre")}>Sobre</button>
          <button onClick={() => scrollTo("tipos")}>Tipos</button>
          <button onClick={() => scrollTo("sinais")}>Sinais</button>
          <button onClick={() => scrollTo("ajuda")}>Ajuda</button>
        </div>
        <div className="sources">
          <strong>Fontes oficiais consultadas</strong>
          {sources.map((s) => (
            <a href={s.href} target="_blank" rel="noreferrer" key={s.href}>{s.label}</a>
          ))}
        </div>
      </div>
      <div className="container footer-bottom">
        <span>Projeto educativo de conscientização social.</span>
        <span>O conteúdo não substitui orientação profissional, jurídica ou atendimento especializado.</span>
      </div>
    </footer>
  );
}
