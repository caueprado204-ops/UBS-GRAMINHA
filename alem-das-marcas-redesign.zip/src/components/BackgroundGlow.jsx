import React from "react";

/**
 * Camada de luz difusa para o fundo de uma seção.
 * `variant` seleciona uma composição de gradientes distinta,
 * para que cada seção tenha uma "iluminação" própria.
 */
export default function BackgroundGlow({ variant = "a", className = "" }) {
  return <div className={`bg-glow bg-glow-${variant} ${className}`} aria-hidden="true" />;
}
