import React from "react";
import { BookOpen } from "lucide-react";
import { violenceTypes } from "../data.js";
import ViolenceCard from "./ViolenceCard.jsx";
import BackgroundGlow from "./BackgroundGlow.jsx";

export default function ViolenceTypes({ openType, setOpenType }) {
  return (
    <section id="tipos" className="section types-section">
      <BackgroundGlow variant="types" />
      <div className="container">
        <div className="section-heading reveal">
          <div>
            <div className="section-kicker">02 — RECONHEÇA</div>
            <h2>06 formas<br />de violência</h2>
          </div>
          <p>A violência doméstica e familiar pode assumir formas diferentes. Conhecê-las ajuda a nomear situações que muitas vezes são normalizadas.</p>
        </div>

        <div className="types-grid">
          {violenceTypes.map((type, index) => (
            <ViolenceCard
              key={type.id}
              type={type}
              index={index}
              isOpen={openType === type.id}
              onToggle={() => setOpenType(openType === type.id ? null : type.id)}
            />
          ))}
        </div>

        <div className="legal-note">
          <BookOpen size={18} />
          <p>
            No Brasil, a Lei Maria da Penha reconhece as violências física, psicológica, sexual,
            patrimonial, moral e, desde 2026, também a violência vicária. Os exemplos desta página
            são educativos e não substituem análise profissional ou jurídica.
          </p>
        </div>
      </div>
    </section>
  );
}
