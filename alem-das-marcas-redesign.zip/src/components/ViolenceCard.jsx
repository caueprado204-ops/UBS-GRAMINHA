import React from "react";
import { ChevronDown, ChevronUp } from "lucide-react";

export default function ViolenceCard({ type, index, isOpen, onToggle }) {
  const Icon = type.icon;
  return (
    <article className={`type-card reveal delay-${(index % 3) + 1} ${isOpen ? "is-open" : ""}`}>
      <span className="type-ghost-number" aria-hidden="true">0{index + 1}</span>
      <div className="type-top">
        <div className="icon-box"><Icon size={20} /></div>
        <span className="type-number">0{index + 1}</span>
      </div>
      <h3>{type.title}</h3>
      <p>{type.short}</p>
      <button
        className="learn-more"
        aria-expanded={isOpen}
        onClick={onToggle}
      >
        {isOpen ? "OCULTAR EXEMPLOS" : "SAIBA MAIS"}
        {isOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
      </button>
      <div className={`examples ${isOpen ? "expanded" : ""}`}>
        <ul>
          {type.examples.map((example) => <li key={example}>{example}</li>)}
        </ul>
      </div>
    </article>
  );
}
