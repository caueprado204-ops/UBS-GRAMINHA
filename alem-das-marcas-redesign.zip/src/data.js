import {
  ShieldCheck, HeartHandshake, MessageCircle, Ban, WalletCards, Users
} from "lucide-react";

export const violenceTypes = [
  {
    id: "fisica",
    title: "Violência Física",
    icon: ShieldCheck,
    short: "Ações que ofendem ou podem ofender a integridade e a saúde corporal.",
    examples: ["Espancamento", "Atirar objetos, sacudir ou apertar os braços", "Estrangulamento ou sufocamento", "Lesões com objetos cortantes ou perfurantes", "Ferimentos por queimaduras ou armas de fogo", "Tortura"]
  },
  {
    id: "sexual",
    title: "Violência Sexual",
    icon: HeartHandshake,
    short: "Quando a mulher é obrigada, pressionada ou impedida de exercer livremente sua sexualidade e seus direitos reprodutivos.",
    examples: ["Estupro", "Obrigar a realizar atos sexuais indesejados", "Impedir o uso de métodos contraceptivos", "Forçar aborto ou gravidez", "Forçar matrimônio ou prostituição por coação, chantagem ou manipulação", "Limitar ou anular direitos sexuais e reprodutivos"]
  },
  {
    id: "psicologica",
    title: "Violência Psicológica",
    icon: MessageCircle,
    short: "Comportamentos que provocam sofrimento emocional, diminuem a autoestima ou controlam a liberdade.",
    examples: ["Ameaças e constrangimento", "Humilhação e insultos", "Manipulação e chantagem", "Isolamento de amigos e familiares", "Vigilância constante e perseguição", "Impedir estudar, trabalhar, viajar ou sair", "Ridicularização", "Gaslighting: distorcer fatos para fazê-la duvidar da própria percepção"]
  },
  {
    id: "moral",
    title: "Violência Moral",
    icon: Ban,
    short: "Atitudes que atacam a honra, a reputação ou a dignidade da mulher.",
    examples: ["Acusar a mulher de traição", "Emitir julgamentos morais sobre sua conduta", "Fazer críticas ou acusações mentirosas", "Expor sua vida íntima", "Xingamentos relacionados à sua índole", "Desvalorizar a mulher por sua aparência ou modo de se vestir"]
  },
  {
    id: "patrimonial",
    title: "Violência Patrimonial",
    icon: WalletCards,
    short: "Controle, destruição, retenção ou retirada de bens, documentos e recursos econômicos.",
    examples: ["Controlar o dinheiro", "Deixar de pagar pensão alimentícia", "Destruir documentos pessoais", "Furto, extorsão ou dano", "Estelionato", "Privar a mulher de bens, valores ou recursos econômicos", "Destruir objetos pessoais ou instrumentos de trabalho"]
  },
  {
    id: "vicaria",
    title: "Violência Vicária",
    icon: Users,
    short: "Uso de filhos, familiares, dependentes ou pessoas da rede de apoio para atingir a mulher.",
    examples: ["Ameaçar machucar filhos para atingir a mulher", "Agressões contra filhos, familiares ou pessoas próximas", "Manipular filhos para rejeitarem a mãe", "Dificultar o convívio da mãe com os filhos como punição", "Usar filhos para transmitir ameaças ou chantagens", "Sequestrar, ocultar ou reter filhos", "Ameaçar ou ferir animais de estimação", "Ameaçar pessoas da rede de apoio", "Provocar sofrimento aos filhos para atingir emocionalmente a mãe", "Em casos extremos, matar filhos ou familiares para causar sofrimento permanente — vicaricídio"]
  }
];

export const signs = [
  "Ele controla com quem você pode conversar?",
  "Ele exige acesso às suas mensagens e redes sociais?",
  "Você tem medo da reação dele quando diz não?",
  "Ele controla seu dinheiro?",
  "Ele ameaça machucar seus filhos ou pessoas próximas?",
  "Ele faz você acreditar que está ficando louca ou que está imaginando coisas?",
  "Ele impede você de estudar, trabalhar, viajar ou encontrar pessoas próximas?"
];

export const myths = [
  ["Violência só existe quando há agressão física.", "MITO", "A violência pode ocorrer sem agressão física. Controle financeiro, ameaças e humilhações, por exemplo, podem integrar situações abusivas."],
  ["Controlar o dinheiro da mulher pode ser uma forma de violência.", "VERDADE", "O controle financeiro é uma forma reconhecida de violência patrimonial, usada para limitar a autonomia e a liberdade da mulher."],
  ["Humilhações e ameaças também podem ser violência.", "VERDADE", "Humilhações, ameaças e constrangimentos são formas de violência psicológica, mesmo sem deixar marcas visíveis."],
  ["Ciúme é sempre uma prova de amor.", "MITO", "Ciúme, controle, humilhação e outras condutas podem ser sinais de abuso. Violência não é prova de amor."],
  ["Impedir o contato com amigos e familiares pode ser uma forma de controle.", "VERDADE", "O isolamento da rede de apoio é uma estratégia comum de controle e pode caracterizar violência psicológica."]
];

export const quotes = [
  "Você não precisa esperar a violência ficar física para pedir ajuda.",
  "Controle não é cuidado.",
  "Ciúme não justifica violência.",
  "Sua liberdade importa.",
  "Você merece respeito."
];

export const helpLinks = [
  {
    href: "https://www.gov.br/pt-br/servicos/denunciar-e-buscar-ajuda-a-vitimas-de-violencia-contra-mulheres",
    overline: "CENTRAL DE ATENDIMENTO À MULHER",
    title: "Ligue 180",
    text: "Serviço oficial do Governo Federal para informações, acolhimento, orientação e encaminhamento de denúncias. Atendimento 24 horas."
  },
  {
    href: "https://www.gov.br/mulheres/pt-br/central-de-conteudos/campanhas/2026/carnaval",
    overline: "INFORMAÇÃO OFICIAL",
    title: "Serviços e direitos",
    text: "Consulte informações atualizadas do Governo Federal sobre direitos, proteção e enfrentamento à violência contra a mulher."
  }
];

export const sources = [
  { href: "https://www.planalto.gov.br/ccivil_03/_ato2004-2006/2006/lei/l11340.htm", label: "Lei Maria da Penha — Planalto" },
  { href: "https://www.gov.br/mj/pt-br/assuntos/sua-seguranca/seguranca-publica/susp-mulheres/violencia-domestica-e-familiar", label: "Ministério da Justiça e Segurança Pública" },
  { href: "https://www.gov.br/pt-br/servicos/denunciar-e-buscar-ajuda-a-vitimas-de-violencia-contra-mulheres", label: "Governo Federal — buscar ajuda" }
];
