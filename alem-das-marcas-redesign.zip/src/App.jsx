import React, { useEffect, useState } from "react";
import { ArrowUp } from "lucide-react";

import Navbar from "./components/Navbar.jsx";
import Hero from "./components/Hero.jsx";
import EditorialIntro from "./components/EditorialIntro.jsx";
import ViolenceTypes from "./components/ViolenceTypes.jsx";
import SignsSection from "./components/SignsSection.jsx";
import MythsSection from "./components/MythsSection.jsx";
import QuoteSection from "./components/QuoteSection.jsx";
import HelpSection from "./components/HelpSection.jsx";
import Footer from "./components/Footer.jsx";

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [openType, setOpenType] = useState(null);
  const [checkedSigns, setCheckedSigns] = useState([]);
  const [openMyth, setOpenMyth] = useState(null);
  const [showTop, setShowTop] = useState(false);

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 500);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const toggleSign = (index) =>
    setCheckedSigns((current) =>
      current.includes(index) ? current.filter((i) => i !== index) : [...current, index]
    );

  const scrollTo = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    setMenuOpen(false);
  };

  return (
    <div className="site-shell">
      <Navbar menuOpen={menuOpen} setMenuOpen={setMenuOpen} scrollTo={scrollTo} />

      <main>
        <Hero scrollTo={scrollTo} />
        <EditorialIntro />
        <ViolenceTypes openType={openType} setOpenType={setOpenType} />
        <SignsSection checkedSigns={checkedSigns} toggleSign={toggleSign} />
        <MythsSection openMyth={openMyth} setOpenMyth={setOpenMyth} />
        <QuoteSection />
        <HelpSection />
      </main>

      <Footer scrollTo={scrollTo} />

      {showTop && (
        <button className="to-top" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} aria-label="Voltar ao topo">
          <ArrowUp size={18} />
        </button>
      )}
    </div>
  );
}
